package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DeviceDao {

    @Query("SELECT * FROM devices ORDER BY lastSeenTimestamp DESC")
    fun getAllDevices(): Flow<List<DeviceEntity>>

    @Query("SELECT * FROM devices WHERE id = :id")
    fun getDeviceById(id: Long): Flow<DeviceEntity?>

    @Query("""
        SELECT * FROM devices 
        WHERE (:query = '' OR name LIKE '%' || :query || '%' 
               OR brand LIKE '%' || :query || '%' 
               OR model LIKE '%' || :query || '%' 
               OR locationName LIKE '%' || :query || '%' 
               OR networkType LIKE '%' || :query || '%' 
               OR notes LIKE '%' || :query || '%')
          AND (:category = 'ALL' OR category = :category)
        ORDER BY 
            CASE WHEN :sortOrder = 'LAST_SEEN_DESC' THEN lastSeenTimestamp END DESC,
            CASE WHEN :sortOrder = 'BATTERY_DESC' THEN batteryPercent END DESC,
            CASE WHEN :sortOrder = 'BATTERY_ASC' THEN batteryPercent END ASC,
            CASE WHEN :sortOrder = 'NAME_ASC' THEN name END ASC,
            lastSeenTimestamp DESC
    """)
    fun filterAndSearchDevices(
        query: String,
        category: String,
        sortOrder: String
    ): Flow<List<DeviceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDevices(devices: List<DeviceEntity>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDevice(device: DeviceEntity): Long

    @Update
    suspend fun updateDevice(device: DeviceEntity)

    @Delete
    suspend fun deleteDevice(device: DeviceEntity)

    @Query("DELETE FROM devices WHERE id = :id")
    suspend fun deleteDeviceById(id: Long)

    @Query("DELETE FROM devices")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM devices")
    fun getDeviceCount(): Flow<Int>
}
