package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "devices")
data class DeviceEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val externalId: String,
    val name: String,
    val brand: String,
    val model: String,
    val category: String, // PHONE, TABLET, WATCH, EARBUDS, TRACKER_TAG, LAPTOP, BELONGING
    val batteryPercent: Int, // 0..100 or -1 if unavailable
    val isCharging: Boolean = false,
    val status: String, // ONLINE, NEARBY, LAST_SEEN, RINGING, LOST
    val networkType: String, // "Wi-Fi (Home_5G)", "Cellular 5G", "Bluetooth Mesh", "Find My Device Network"
    val locationName: String,
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float = 10f,
    val lastSeenTimestamp: Long = System.currentTimeMillis(),
    val isLostMode: Boolean = false,
    val ringCount: Int = 0,
    val notes: String = "",
    val ownerEmail: String = "karimsak04@gmail.com",
    val scrapedSource: String = "https://www.google.com/android/find/",
    val scrapedAt: Long = System.currentTimeMillis()
)
