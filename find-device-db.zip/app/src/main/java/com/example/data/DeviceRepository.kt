package com.example.data

import kotlinx.coroutines.flow.Flow

class DeviceRepository(private val deviceDao: DeviceDao) {

    val allDevices: Flow<List<DeviceEntity>> = deviceDao.getAllDevices()
    val deviceCount: Flow<Int> = deviceDao.getDeviceCount()

    fun getDeviceById(id: Long): Flow<DeviceEntity?> = deviceDao.getDeviceById(id)

    fun filterAndSearchDevices(
        query: String,
        category: String,
        sortOrder: String
    ): Flow<List<DeviceEntity>> = deviceDao.filterAndSearchDevices(query, category, sortOrder)

    suspend fun insertDevices(devices: List<DeviceEntity>) = deviceDao.insertDevices(devices)

    suspend fun insertDevice(device: DeviceEntity) = deviceDao.insertDevice(device)

    suspend fun updateDevice(device: DeviceEntity) = deviceDao.updateDevice(device)

    suspend fun deleteDevice(device: DeviceEntity) = deviceDao.deleteDevice(device)

    suspend fun deleteDeviceById(id: Long) = deviceDao.deleteDeviceById(id)

    suspend fun clearAll() = deviceDao.clearAll()
}
