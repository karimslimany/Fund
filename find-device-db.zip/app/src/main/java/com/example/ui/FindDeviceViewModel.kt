package com.example.ui

import android.app.Application
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.DeviceEntity
import com.example.data.DeviceRepository
import com.example.data.FindDeviceScraper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

enum class DeviceSort(val label: String, val key: String) {
    LAST_SEEN("Last Seen", "LAST_SEEN_DESC"),
    BATTERY_HIGH("Battery (High-Low)", "BATTERY_DESC"),
    BATTERY_LOW("Battery (Low-High)", "BATTERY_ASC"),
    NAME("Name (A-Z)", "NAME_ASC")
}

data class ScraperUiState(
    val isScraping: Boolean = false,
    val targetUrl: String = FindDeviceScraper.DEFAULT_FIND_URL,
    val logs: List<String> = emptyList(),
    val lastScrapeTime: Long? = null,
    val lastScrapedCount: Int = 0,
    val statusMessage: String? = null
)

class FindDeviceViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: DeviceRepository
    private var toneGenerator: ToneGenerator? = null

    // Search and Filter States
    val searchQuery = MutableStateFlow("")
    val selectedCategory = MutableStateFlow("ALL")
    val selectedStatusFilter = MutableStateFlow("ALL") // "ALL", "ONLINE", "NEARBY", "LOW_BATTERY", "LOST"
    val sortOrder = MutableStateFlow(DeviceSort.LAST_SEEN)

    // Navigation and UI states
    val activeTab = MutableStateFlow(0) // 0: Inventory/Search, 1: Live Radar, 2: Web Scraper Hub, 3: Fleet Analytics
    val selectedDevice = MutableStateFlow<DeviceEntity?>(null)
    val isAddEditOpen = MutableStateFlow(false)
    val editingDevice = MutableStateFlow<DeviceEntity?>(null)
    val ringingDeviceId = MutableStateFlow<Long?>(null)
    val userNotification = MutableStateFlow<String?>(null)

    // Scraper state
    private val _scraperState = MutableStateFlow(ScraperUiState())
    val scraperState: StateFlow<ScraperUiState> = _scraperState.asStateFlow()

    init {
        val db = AppDatabase.getDatabase(application)
        repository = DeviceRepository(db.deviceDao())

        // Initial launch check: populate sample fleet if database is empty
        viewModelScope.launch(Dispatchers.IO) {
            val initialList = repository.allDevices
            initialList.collect { list ->
                if (list.isEmpty()) {
                    val defaultFleet = FindDeviceScraper.getPreloadedFindMyDeviceFleet()
                    repository.insertDevices(defaultFleet)
                    _scraperState.value = _scraperState.value.copy(
                        logs = listOf(
                            "Database initialized.",
                            "Populated 10 certified Google Find My Device items from ${FindDeviceScraper.DEFAULT_FIND_URL}"
                        ),
                        lastScrapeTime = System.currentTimeMillis(),
                        lastScrapedCount = defaultFleet.size
                    )
                }
            }
        }
    }

    // Core Reactive Filtered Devices List
    val filteredDevices: StateFlow<List<DeviceEntity>> = combine(
        repository.allDevices,
        searchQuery,
        selectedCategory,
        selectedStatusFilter,
        sortOrder
    ) { devices, query, category, statusFilter, sort ->
        var list = devices

        // Category filter
        if (category != "ALL") {
            list = list.filter { it.category.equals(category, ignoreCase = true) }
        }

        // Status / Health filter
        when (statusFilter) {
            "ONLINE" -> list = list.filter { it.status.equals("ONLINE", ignoreCase = true) }
            "NEARBY" -> list = list.filter { it.status.equals("NEARBY", ignoreCase = true) }
            "LOW_BATTERY" -> list = list.filter { it.batteryPercent in 0..20 }
            "LOST" -> list = list.filter { it.isLostMode }
        }

        // Text query filter
        if (query.isNotBlank()) {
            val q = query.trim().lowercase()
            list = list.filter {
                it.name.lowercase().contains(q) ||
                        it.brand.lowercase().contains(q) ||
                        it.model.lowercase().contains(q) ||
                        it.locationName.lowercase().contains(q) ||
                        it.networkType.lowercase().contains(q) ||
                        it.notes.lowercase().contains(q)
            }
        }

        // Sorting
        when (sort) {
            DeviceSort.LAST_SEEN -> list.sortedByDescending { it.lastSeenTimestamp }
            DeviceSort.BATTERY_HIGH -> list.sortedByDescending { it.batteryPercent }
            DeviceSort.BATTERY_LOW -> list.sortedBy { it.batteryPercent }
            DeviceSort.NAME -> list.sortedBy { it.name.lowercase() }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allDevicesList: StateFlow<List<DeviceEntity>> = repository.allDevices.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val deviceCount: StateFlow<Int> = repository.deviceCount.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    fun setSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun setCategory(category: String) {
        selectedCategory.value = category
    }

    fun setStatusFilter(filter: String) {
        selectedStatusFilter.value = filter
    }

    fun setSortOrder(sort: DeviceSort) {
        sortOrder.value = sort
    }

    fun selectDevice(device: DeviceEntity?) {
        selectedDevice.value = device
    }

    fun openAddDevice() {
        editingDevice.value = null
        isAddEditOpen.value = true
    }

    fun openEditDevice(device: DeviceEntity) {
        editingDevice.value = device
        isAddEditOpen.value = true
    }

    fun dismissAddEdit() {
        isAddEditOpen.value = false
        editingDevice.value = null
    }

    fun saveDevice(device: DeviceEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            if (device.id == 0L) {
                repository.insertDevice(device)
                showNotification("Added \"${device.name}\" to database")
            } else {
                repository.updateDevice(device)
                showNotification("Updated \"${device.name}\"")
            }
            dismissAddEdit()
            if (selectedDevice.value?.id == device.id) {
                selectedDevice.value = device
            }
        }
    }

    fun deleteDevice(device: DeviceEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteDevice(device)
            if (selectedDevice.value?.id == device.id) {
                selectedDevice.value = null
            }
            showNotification("Deleted \"${device.name}\"")
        }
    }

    fun toggleLostMode(device: DeviceEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = device.copy(
                isLostMode = !device.isLostMode,
                status = if (!device.isLostMode) "LOST" else "ONLINE"
            )
            repository.updateDevice(updated)
            if (selectedDevice.value?.id == device.id) {
                selectedDevice.value = updated
            }
            val msg = if (updated.isLostMode) {
                "\"${device.name}\" marked as LOST. Network alerts enabled."
            } else {
                "\"${device.name}\" recovered. Lost mode deactivated."
            }
            showNotification(msg)
        }
    }

    fun triggerRingDevice(device: DeviceEntity) {
        val app = getApplication<Application>()
        ringingDeviceId.value = device.id

        viewModelScope.launch(Dispatchers.IO) {
            val updated = device.copy(ringCount = device.ringCount + 1)
            repository.updateDevice(updated)
            if (selectedDevice.value?.id == device.id) {
                selectedDevice.value = updated
            }

            // Audio tone alert
            try {
                if (toneGenerator == null) {
                    toneGenerator = ToneGenerator(AudioManager.STREAM_ALARM, 100)
                }
                toneGenerator?.startTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, 3000)
            } catch (_: Exception) {}

            // Vibration alert
            try {
                val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val manager = app.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                    manager?.defaultVibrator
                } else {
                    @Suppress("DEPRECATION")
                    app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(
                        VibrationEffect.createWaveform(longArrayOf(0, 500, 200, 500, 200, 500), -1)
                    )
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(longArrayOf(0, 500, 200, 500, 200, 500), -1)
                }
            } catch (_: Exception) {}

            showNotification("Ringing \"${device.name}\" at max volume...")
        }
    }

    fun stopRinging() {
        ringingDeviceId.value = null
        try {
            toneGenerator?.stopTone()
            toneGenerator?.release()
            toneGenerator = null
        } catch (_: Exception) {}

        val app = getApplication<Application>()
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager = app.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                manager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            vibrator?.cancel()
        } catch (_: Exception) {}
    }

    // Web Scraping Trigger
    fun startUrlScrape(url: String = FindDeviceScraper.DEFAULT_FIND_URL) {
        viewModelScope.launch {
            _scraperState.value = _scraperState.value.copy(
                isScraping = true,
                targetUrl = url,
                statusMessage = "Connecting to Google Find My Device ($url)..."
            )

            val result = FindDeviceScraper.scrapeUrl(url)

            if (result.itemsScraped.isNotEmpty()) {
                repository.insertDevices(result.itemsScraped)
            }

            _scraperState.value = _scraperState.value.copy(
                isScraping = false,
                logs = result.logMessages,
                lastScrapeTime = System.currentTimeMillis(),
                lastScrapedCount = result.itemsScraped.size,
                statusMessage = "Scraped & synced ${result.itemsScraped.size} devices into database."
            )
            showNotification("Scrape complete: ${result.itemsScraped.size} devices organized!")
        }
    }

    fun parseAndIngestRawInput(input: String) {
        viewModelScope.launch {
            _scraperState.value = _scraperState.value.copy(
                isScraping = true,
                statusMessage = "Parsing input payload..."
            )

            val result = FindDeviceScraper.scrapeFromRawInput(input)
            if (result.itemsScraped.isNotEmpty()) {
                repository.insertDevices(result.itemsScraped)
            }

            _scraperState.value = _scraperState.value.copy(
                isScraping = false,
                logs = result.logMessages,
                lastScrapeTime = System.currentTimeMillis(),
                lastScrapedCount = result.itemsScraped.size,
                statusMessage = "Extracted and saved ${result.itemsScraped.size} items."
            )
            showNotification("Extracted ${result.itemsScraped.size} items into database.")
        }
    }

    fun resetToSampleFleet() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearAll()
            val fleet = FindDeviceScraper.getPreloadedFindMyDeviceFleet()
            repository.insertDevices(fleet)
            _scraperState.value = _scraperState.value.copy(
                logs = listOf(
                    "Cleared existing database.",
                    "Re-scraped and organized standard 10 devices from ${FindDeviceScraper.DEFAULT_FIND_URL}"
                ),
                lastScrapeTime = System.currentTimeMillis(),
                lastScrapedCount = fleet.size,
                statusMessage = "Reset to fresh Google Find My Device inventory."
            )
            showNotification("Database reset with 10 tracked devices.")
        }
    }

    fun clearAllDatabase() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearAll()
            selectedDevice.value = null
            _scraperState.value = _scraperState.value.copy(
                statusMessage = "All devices cleared from local database."
            )
            showNotification("Database cleared.")
        }
    }

    fun exportDatabaseToJson(): String {
        val list = allDevicesList.value
        val array = JSONArray()
        for (device in list) {
            val obj = JSONObject().apply {
                put("id", device.id)
                put("externalId", device.externalId)
                put("name", device.name)
                put("brand", device.brand)
                put("model", device.model)
                put("category", device.category)
                put("batteryPercent", device.batteryPercent)
                put("isCharging", device.isCharging)
                put("status", device.status)
                put("networkType", device.networkType)
                put("locationName", device.locationName)
                put("latitude", device.latitude)
                put("longitude", device.longitude)
                put("accuracyMeters", device.accuracyMeters)
                put("lastSeenTimestamp", device.lastSeenTimestamp)
                put("isLostMode", device.isLostMode)
                put("notes", device.notes)
                put("scrapedSource", device.scrapedSource)
                put("scrapedAt", device.scrapedAt)
            }
            array.put(obj)
        }
        return array.toString(2)
    }

    fun showNotification(message: String) {
        userNotification.value = message
    }

    fun clearNotification() {
        userNotification.value = null
    }

    override fun onCleared() {
        super.onCleared()
        stopRinging()
    }
}
