package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Laptop
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Tablet
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Watch
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DeviceEntity
import com.example.ui.theme.BatteryCritical
import com.example.ui.theme.BatteryGood
import com.example.ui.theme.BatteryLow
import com.example.ui.theme.StatusAlert
import com.example.ui.theme.StatusNearby
import com.example.ui.theme.StatusOnline
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DeviceCard(
    device: DeviceEntity,
    isRinging: Boolean,
    onClick: () -> Unit,
    onRingClick: () -> Unit,
    onToggleLostMode: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    val isLost = device.isLostMode
    val isLowBattery = device.batteryPercent in 0..20

    val cardBorder = when {
        isRinging -> Modifier.border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(16.dp))
        isLost -> Modifier.border(1.5.dp, StatusAlert, RoundedCornerShape(16.dp))
        else -> Modifier.border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .then(cardBorder)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag("device_card_${device.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isLost) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.15f)
            else MaterialTheme.colorScheme.surfaceVariant
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header Row: Icon, Name, Category Pill, Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Category Device Icon Box
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(getCategoryColor(device.category).copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = getCategoryIcon(device.category, device.name),
                        contentDescription = device.category,
                        tint = getCategoryColor(device.category),
                        modifier = Modifier.size(26.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = device.name,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${device.brand} • ${device.model}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Status Pill
                StatusPill(
                    status = device.status,
                    isLost = isLost,
                    isRinging = isRinging,
                    pulseAlpha = pulseAlpha
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Battery and Network status row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Battery Bar
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    val batteryColor = when {
                        device.batteryPercent > 50 -> BatteryGood
                        device.batteryPercent > 20 -> BatteryLow
                        else -> BatteryCritical
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${device.batteryPercent}%",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = batteryColor
                            )
                            if (device.isCharging) {
                                Icon(
                                    imageVector = Icons.Default.Bolt,
                                    contentDescription = "Charging",
                                    tint = batteryColor,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                            if (isLowBattery && !device.isCharging) {
                                Text(
                                    text = " • Low Battery",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = BatteryCritical
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        LinearProgressIndicator(
                            progress = { (device.batteryPercent.coerceIn(0, 100) / 100f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(5.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = batteryColor,
                            trackColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                // Network Tag
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)
                ) {
                    Text(
                        text = device.networkType,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Location and Last Seen Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = "Location",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = device.locationName,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = formatTimeAgo(device.lastSeenTimestamp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Ring Button
                FilledTonalButton(
                    onClick = onRingClick,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ring_button_${device.id}"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = if (isRinging) Icons.Default.NotificationsActive else Icons.Default.VolumeUp,
                        contentDescription = "Play Sound",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isRinging) "Stop Sound" else "Play Sound",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Lost Mode Toggle Button
                OutlinedButton(
                    onClick = onToggleLostMode,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("lost_toggle_${device.id}")
                ) {
                    Icon(
                        imageVector = if (isLost) Icons.Outlined.Lock else Icons.Outlined.LockOpen,
                        contentDescription = if (isLost) "Lost Active" else "Mark Lost",
                        tint = if (isLost) StatusAlert else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isLost) "Lost" else "Secure",
                        fontSize = 12.sp,
                        color = if (isLost) StatusAlert else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun StatusPill(
    status: String,
    isLost: Boolean,
    isRinging: Boolean,
    pulseAlpha: Float
) {
    val (label, bgColor, textColor) = when {
        isRinging -> Triple("RINGING", MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.onPrimary)
        isLost -> Triple("LOST MODE", StatusAlert, Color.White)
        status.equals("ONLINE", true) -> Triple("ONLINE", StatusOnline.copy(alpha = 0.2f), StatusOnline)
        status.equals("NEARBY", true) -> Triple("NEARBY", StatusNearby.copy(alpha = 0.2f), StatusNearby)
        else -> Triple("LAST SEEN", Color.Gray.copy(alpha = 0.2f), Color.LightGray)
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = bgColor,
        modifier = if (isRinging || isLost) Modifier.alpha(pulseAlpha) else Modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(textColor)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = textColor
            )
        }
    }
}

fun getCategoryIcon(category: String, name: String): ImageVector {
    val lower = name.lowercase()
    return when {
        lower.contains("bike") -> Icons.Default.DirectionsBike
        lower.contains("key") -> Icons.Default.Key
        category.equals("PHONE", true) -> Icons.Default.Smartphone
        category.equals("TABLET", true) -> Icons.Default.Tablet
        category.equals("WATCH", true) -> Icons.Default.Watch
        category.equals("EARBUDS", true) -> Icons.Default.Headphones
        category.equals("TRACKER_TAG", true) -> Icons.Default.Sensors
        category.equals("LAPTOP", true) -> Icons.Default.Laptop
        else -> Icons.Default.PhoneAndroid
    }
}

fun getCategoryColor(category: String): Color {
    return when (category.uppercase()) {
        "PHONE" -> Color(0xFF0284C7)
        "TABLET" -> Color(0xFF6366F1)
        "WATCH" -> Color(0xFF10B981)
        "EARBUDS" -> Color(0xFF8B5CF6)
        "TRACKER_TAG" -> Color(0xFF06B6D4)
        "LAPTOP" -> Color(0xFF3B82F6)
        "BELONGING" -> Color(0xFFF59E0B)
        else -> Color(0xFF64748B)
    }
}

fun formatTimeAgo(timestamp: Long): String {
    val diff = System.currentTimeMillis() - timestamp
    val seconds = diff / 1000
    val minutes = seconds / 60
    val hours = minutes / 60
    val days = hours / 24

    return when {
        minutes < 1 -> "Just now"
        minutes < 60 -> "${minutes}m ago"
        hours < 24 -> "${hours}h ago"
        days < 7 -> "${days}d ago"
        else -> SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(timestamp))
    }
}
