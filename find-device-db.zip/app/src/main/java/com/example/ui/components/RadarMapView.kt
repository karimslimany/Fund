package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DeviceEntity
import com.example.ui.theme.BatteryCritical
import com.example.ui.theme.BatteryGood
import com.example.ui.theme.BatteryLow
import com.example.ui.theme.FindBlueDark
import com.example.ui.theme.FindCyanDark
import com.example.ui.theme.StatusAlert
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun RadarMapView(
    devices: List<DeviceEntity>,
    selectedDevice: DeviceEntity?,
    onSelectDevice: (DeviceEntity) -> Unit,
    onRingDevice: (DeviceEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "radar")
    val sweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sweepAngle"
    )

    var activeBlipDevice by remember { mutableStateOf(selectedDevice) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Radar Screen Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Find Network Proximity Radar",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Encrypted Bluetooth Mesh & GPS Pinpoints",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Surface(
                shape = RoundedCornerShape(20.dp),
                color = FindCyanDark.copy(alpha = 0.15f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(FindCyanDark)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "RADAR SCANNING",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = FindCyanDark
                    )
                }
            }
        }

        // Radar Canvas Box
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF070B14)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .border(1.5.dp, Color(0xFF1E293B), RoundedCornerShape(24.dp))
                .testTag("radar_display_card")
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(devices) {
                            detectTapGestures { tapOffset ->
                                val center = Offset(size.width / 2f, size.height / 2f)
                                val radius = minOf(size.width, size.height) / 2f * 0.85f

                                // Check which device was tapped
                                val centerLat = 37.4220
                                val centerLng = -122.0841

                                devices.forEachIndexed { index, dev ->
                                    val angleDeg = (index * (360f / devices.size.coerceAtLeast(1)))
                                    val angleRad = Math.toRadians(angleDeg.toDouble())
                                    val distFraction = 0.25f + ((index % 3 + 1) * 0.22f)
                                    val blipX = center.x + (radius * distFraction * cos(angleRad)).toFloat()
                                    val blipY = center.y + (radius * distFraction * sin(angleRad)).toFloat()

                                    val distToTap = kotlin.math.hypot(tapOffset.x - blipX, tapOffset.y - blipY)
                                    if (distToTap < 30.dp.toPx()) {
                                        activeBlipDevice = dev
                                        onSelectDevice(dev)
                                    }
                                }
                            }
                        }
                ) {
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val maxRadius = size.minDimension / 2f * 0.88f

                    // Draw concentric rings
                    val rings = 4
                    for (i in 1..rings) {
                        val r = maxRadius * (i / rings.toFloat())
                        drawCircle(
                            color = Color(0xFF1E3A8A).copy(alpha = 0.35f),
                            radius = r,
                            center = center,
                            style = Stroke(width = 1.5.dp.toPx())
                        )
                    }

                    // Crosshairs
                    drawLine(
                        color = Color(0xFF1E3A8A).copy(alpha = 0.3f),
                        start = Offset(center.x, center.y - maxRadius),
                        end = Offset(center.x, center.y + maxRadius),
                        strokeWidth = 1.dp.toPx()
                    )
                    drawLine(
                        color = Color(0xFF1E3A8A).copy(alpha = 0.3f),
                        start = Offset(center.x - maxRadius, center.y),
                        end = Offset(center.x + maxRadius, center.y),
                        strokeWidth = 1.dp.toPx()
                    )

                    // Radar sweep beam
                    val sweepRad = Math.toRadians(sweepAngle.toDouble())
                    val sweepEnd = Offset(
                        x = center.x + (maxRadius * cos(sweepRad)).toFloat(),
                        y = center.y + (maxRadius * sin(sweepRad)).toFloat()
                    )

                    drawLine(
                        brush = Brush.linearGradient(
                            colors = listOf(FindCyanDark, Color.Transparent),
                            start = center,
                            end = sweepEnd
                        ),
                        start = center,
                        end = sweepEnd,
                        strokeWidth = 2.5.dp.toPx()
                    )

                    // Center user position blip
                    drawCircle(
                        color = FindBlueDark,
                        radius = 8.dp.toPx(),
                        center = center
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 3.dp.toPx(),
                        center = center
                    )

                    // Plot devices as blips
                    devices.forEachIndexed { index, dev ->
                        val angleDeg = (index * (360f / devices.size.coerceAtLeast(1)))
                        val angleRad = Math.toRadians(angleDeg.toDouble())
                        val distFraction = 0.25f + ((index % 3 + 1) * 0.22f)
                        val blipX = center.x + (maxRadius * distFraction * cos(angleRad)).toFloat()
                        val blipY = center.y + (maxRadius * distFraction * sin(angleRad)).toFloat()
                        val blipPos = Offset(blipX, blipY)

                        val isSelected = activeBlipDevice?.id == dev.id
                        val blipColor = when {
                            dev.isLostMode -> StatusAlert
                            dev.batteryPercent <= 20 -> BatteryCritical
                            dev.status.equals("NEARBY", true) -> FindCyanDark
                            else -> FindBlueDark
                        }

                        // Outer ring if selected or lost
                        if (isSelected || dev.isLostMode) {
                            drawCircle(
                                color = blipColor.copy(alpha = 0.4f),
                                radius = 14.dp.toPx(),
                                center = blipPos
                            )
                        }

                        drawCircle(
                            color = blipColor,
                            radius = if (isSelected) 8.dp.toPx() else 6.dp.toPx(),
                            center = blipPos
                        )
                    }
                }

                // Compass orientation markers
                Text(
                    text = "N",
                    color = Color(0xFF64748B),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.TopCenter)
                )
                Text(
                    text = "S",
                    color = Color(0xFF64748B),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
                Text(
                    text = "W",
                    color = Color(0xFF64748B),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.CenterStart)
                )
                Text(
                    text = "E",
                    color = Color(0xFF64748B),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.CenterEnd)
                )
            }
        }

        // Active Blip Inspector Card
        val currentDevice = activeBlipDevice ?: devices.firstOrNull()
        if (currentDevice != null) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = currentDevice.name,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${currentDevice.brand} • ${currentDevice.locationName}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        // Battery Pill
                        val batteryColor = when {
                            currentDevice.batteryPercent > 50 -> BatteryGood
                            currentDevice.batteryPercent > 20 -> BatteryLow
                            else -> BatteryCritical
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = batteryColor.copy(alpha = 0.15f)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "${currentDevice.batteryPercent}%",
                                    color = batteryColor,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                if (currentDevice.isCharging) {
                                    Icon(
                                        imageVector = Icons.Default.Bolt,
                                        contentDescription = "Charging",
                                        tint = batteryColor,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onRingDevice(currentDevice) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "Play Sound",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Play Sound")
                        }

                        Button(
                            onClick = { onSelectDevice(currentDevice) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.NearMe,
                                contentDescription = "Telemetry",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Telemetry")
                        }
                    }
                }
            }
        }

        // Horizontal Quick Switcher
        Text(
            text = "Tracked Fleet Blips",
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            modifier = Modifier.align(Alignment.Start)
        )

        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(devices, key = { it.id }) { dev ->
                val isSelected = activeBlipDevice?.id == dev.id
                FilterChip(
                    selected = isSelected,
                    onClick = {
                        activeBlipDevice = dev
                        onSelectDevice(dev)
                    },
                    label = {
                        Text(
                            text = dev.name,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                )
            }
        }
    }
}
