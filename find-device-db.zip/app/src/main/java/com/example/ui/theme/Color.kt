package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Palette
val FindBlueLight = Color(0xFF0066CC)
val FindBlueOnLight = Color(0xFFFFFFFF)
val FindBlueContainerLight = Color(0xFFD6E4FF)
val FindOnBlueContainerLight = Color(0xFF001B3E)

val FindCyanLight = Color(0xFF009688)
val FindCyanContainerLight = Color(0xFFB2DFDB)
val FindOnCyanContainerLight = Color(0xFF004D40)

val SurfaceLight = Color(0xFFF8FAFD)
val SurfaceContainerLight = Color(0xFFFFFFFF)
val SurfaceContainerHighLight = Color(0xFFEEF2F7)
val OutlineLight = Color(0xFFCBD5E1)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)

// Dark Theme Palette (Find My Device Radar Style)
val FindBlueDark = Color(0xFF38BDF8)
val FindBlueOnDark = Color(0xFF082F49)
val FindBlueContainerDark = Color(0xFF0C4A6E)
val FindOnBlueContainerDark = Color(0xFFBAE6FD)

val FindCyanDark = Color(0xFF2DD4BF)
val FindCyanContainerDark = Color(0xFF134E4A)
val FindOnCyanContainerDark = Color(0xFF99F6E4)

val SurfaceDark = Color(0xFF090D16)
val SurfaceContainerDark = Color(0xFF111827)
val SurfaceContainerHighDark = Color(0xFF1E293B)
val OutlineDark = Color(0xFF334155)
val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)

// Semantic Status Colors
val StatusOnline = Color(0xFF10B981)
val StatusNearby = Color(0xFF06B6D4)
val StatusWarning = Color(0xFFF59E0B)
val StatusAlert = Color(0xFFEF4444)
val BatteryGood = Color(0xFF22C55E)
val BatteryLow = Color(0xFFF97316)
val BatteryCritical = Color(0xFFEF4444)
