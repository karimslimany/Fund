package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DeviceEntity
import com.example.ui.DeviceSort
import com.example.ui.theme.BatteryCritical
import com.example.ui.theme.FindBlueDark
import com.example.ui.theme.StatusAlert
import com.example.ui.theme.StatusOnline

@Composable
fun InventorySearchView(
    devices: List<DeviceEntity>,
    searchQuery: String,
    selectedCategory: String,
    selectedStatusFilter: String,
    sortOrder: DeviceSort,
    ringingDeviceId: Long?,
    onSearchQueryChange: (String) -> Unit,
    onCategoryChange: (String) -> Unit,
    onStatusFilterChange: (String) -> Unit,
    onSortChange: (DeviceSort) -> Unit,
    onDeviceClick: (DeviceEntity) -> Unit,
    onRingClick: (DeviceEntity) -> Unit,
    onToggleLostMode: (DeviceEntity) -> Unit,
    onOpenScraper: () -> Unit,
    onAddDevice: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isSortMenuOpen by remember { mutableStateOf(false) }

    val categories = listOf(
        "ALL" to "All Categories",
        "PHONE" to "Phones",
        "WATCH" to "Watches",
        "EARBUDS" to "Earbuds",
        "TRACKER_TAG" to "Tracker Tags",
        "TABLET" to "Tablets",
        "LAPTOP" to "Laptops",
        "BELONGING" to "Belongings"
    )

    val statuses = listOf(
        "ALL" to "All Status",
        "ONLINE" to "Online",
        "NEARBY" to "Nearby",
        "LOW_BATTERY" to "Low Battery",
        "LOST" to "Lost Mode"
    )

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Search Input Row with Sort Menu
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = { Text("Search by name, brand, location...") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchQueryChange("") }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear Search"
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("search_text_field")
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Sort Dropdown Button
                Box {
                    IconButton(
                        onClick = { isSortMenuOpen = true },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .testTag("sort_menu_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sort,
                            contentDescription = "Sort",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    DropdownMenu(
                        expanded = isSortMenuOpen,
                        onDismissRequest = { isSortMenuOpen = false }
                    ) {
                        DeviceSort.entries.forEach { sort ->
                            DropdownMenuItem(
                                text = { Text(sort.label) },
                                onClick = {
                                    onSortChange(sort)
                                    isSortMenuOpen = false
                                },
                                leadingIcon = {
                                    if (sortOrder == sort) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Active Sort",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            )
                        }
                    }
                }
            }

            // Category Chips LazyRow
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { (catKey, catLabel) ->
                    val isSelected = selectedCategory.equals(catKey, true)
                    FilterChip(
                        selected = isSelected,
                        onClick = { onCategoryChange(catKey) },
                        label = { Text(catLabel, fontSize = 12.sp) },
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.testTag("chip_cat_$catKey")
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Status Filter Chips LazyRow
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(statuses) { (statKey, statLabel) ->
                    val isSelected = selectedStatusFilter.equals(statKey, true)
                    FilterChip(
                        selected = isSelected,
                        onClick = { onStatusFilterChange(statKey) },
                        label = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (statKey == "LOW_BATTERY") {
                                    Icon(
                                        imageVector = Icons.Default.BatteryAlert,
                                        contentDescription = null,
                                        tint = BatteryCritical,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                }
                                Text(statLabel, fontSize = 11.sp)
                            }
                        },
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.testTag("chip_status_$statKey")
                    )
                }
            }

            // Results count and active sort label
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${devices.size} ${if (devices.size == 1) "device" else "devices"} found",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text(
                    text = "Sorted by: ${sortOrder.label}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            // Devices List or Empty State
            if (devices.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SearchOff,
                            contentDescription = "No Results",
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.outline
                        )
                        Text(
                            text = "No devices match your search",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Try clearing your filters or scrape new devices from Google Find My Device.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (searchQuery.isNotBlank() || selectedCategory != "ALL" || selectedStatusFilter != "ALL") {
                                OutlinedButton(
                                    onClick = {
                                        onSearchQueryChange("")
                                        onCategoryChange("ALL")
                                        onStatusFilterChange("ALL")
                                    }
                                ) {
                                    Text("Reset Filters")
                                }
                            }
                            Button(onClick = onOpenScraper) {
                                Icon(
                                    imageVector = Icons.Default.CloudDownload,
                                    contentDescription = "Scraper",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Open Scraper")
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(devices, key = { it.id }) { device ->
                        DeviceCard(
                            device = device,
                            isRinging = ringingDeviceId == device.id,
                            onClick = { onDeviceClick(device) },
                            onRingClick = { onRingClick(device) },
                            onToggleLostMode = { onToggleLostMode(device) }
                        )
                    }
                }
            }
        }

        // Floating Action Button to Add Device Manually
        FloatingActionButton(
            onClick = onAddDevice,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("fab_add_device"),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Add Device"
            )
        }
    }
}
