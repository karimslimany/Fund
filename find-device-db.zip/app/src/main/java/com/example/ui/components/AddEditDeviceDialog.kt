package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.DeviceEntity
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditDeviceDialog(
    initialDevice: DeviceEntity?,
    onDismiss: () -> Unit,
    onSave: (DeviceEntity) -> Unit
) {
    var name by remember { mutableStateOf(initialDevice?.name ?: "") }
    var brand by remember { mutableStateOf(initialDevice?.brand ?: "Google") }
    var model by remember { mutableStateOf(initialDevice?.model ?: "") }
    var category by remember { mutableStateOf(initialDevice?.category ?: "PHONE") }
    var batteryPercent by remember { mutableFloatStateOf(initialDevice?.batteryPercent?.toFloat() ?: 80f) }
    var isCharging by remember { mutableStateOf(initialDevice?.isCharging ?: false) }
    var locationName by remember { mutableStateOf(initialDevice?.locationName ?: "San Francisco, CA") }
    var notes by remember { mutableStateOf(initialDevice?.notes ?: "") }
    var isCategoryDropdownOpen by remember { mutableStateOf(false) }

    val categories = listOf("PHONE", "TABLET", "WATCH", "EARBUDS", "TRACKER_TAG", "LAPTOP", "BELONGING")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialDevice == null) "Add Device to Database" else "Edit Device",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Device Name") },
                    placeholder = { Text("e.g. Pixel 9 Pro XL") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("device_name_input"),
                    shape = RoundedCornerShape(10.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = brand,
                        onValueChange = { brand = it },
                        label = { Text("Brand") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    )

                    OutlinedTextField(
                        value = model,
                        onValueChange = { model = it },
                        label = { Text("Model") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                // Category Selector
                ExposedDropdownMenuBox(
                    expanded = isCategoryDropdownOpen,
                    onExpandedChange = { isCategoryDropdownOpen = !isCategoryDropdownOpen }
                ) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Category") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isCategoryDropdownOpen) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable),
                        shape = RoundedCornerShape(10.dp)
                    )
                    ExposedDropdownMenu(
                        expanded = isCategoryDropdownOpen,
                        onDismissRequest = { isCategoryDropdownOpen = false }
                    ) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat) },
                                onClick = {
                                    category = cat
                                    isCategoryDropdownOpen = false
                                }
                            )
                        }
                    }
                }

                // Battery Slider
                Column {
                    Text(
                        text = "Battery Level: ${batteryPercent.toInt()}%",
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall
                    )
                    Slider(
                        value = batteryPercent,
                        onValueChange = { batteryPercent = it },
                        valueRange = 0f..100f,
                        steps = 20,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Charging Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Currently Charging")
                    Switch(
                        checked = isCharging,
                        onCheckedChange = { isCharging = it }
                    )
                }

                OutlinedTextField(
                    value = locationName,
                    onValueChange = { locationName = it },
                    label = { Text("Last Known Location") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3,
                    shape = RoundedCornerShape(10.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalDevice = initialDevice?.copy(
                        name = name.ifBlank { "Tracked Device" },
                        brand = brand.ifBlank { "Android" },
                        model = model.ifBlank { name },
                        category = category,
                        batteryPercent = batteryPercent.toInt(),
                        isCharging = isCharging,
                        locationName = locationName.ifBlank { "Current Location" },
                        notes = notes
                    ) ?: DeviceEntity(
                        externalId = "manual_${UUID.randomUUID().toString().take(8)}",
                        name = name.ifBlank { "Tracked Device" },
                        brand = brand.ifBlank { "Android" },
                        model = model.ifBlank { name },
                        category = category,
                        batteryPercent = batteryPercent.toInt(),
                        isCharging = isCharging,
                        status = "ONLINE",
                        networkType = "Find My Device Network",
                        locationName = locationName.ifBlank { "Current Location" },
                        latitude = 37.7749,
                        longitude = -122.4194,
                        accuracyMeters = 8f,
                        lastSeenTimestamp = System.currentTimeMillis(),
                        isLostMode = false,
                        notes = notes
                    )
                    onSave(finalDevice)
                },
                enabled = name.isNotBlank(),
                modifier = Modifier.testTag("dialog_save_button")
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
