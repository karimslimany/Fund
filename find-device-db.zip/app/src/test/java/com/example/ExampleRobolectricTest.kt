package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.DeviceEntity
import com.example.data.FindDeviceScraper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Find Device", appName)
  }

  @Test
  fun `verify preloaded fleet contains devices from find my device`() {
    val fleet = FindDeviceScraper.getPreloadedFindMyDeviceFleet()
    assertTrue(fleet.isNotEmpty())
    val pixelPhone = fleet.find { it.category == "PHONE" }
    assertNotNull(pixelPhone)
    assertEquals("Google", pixelPhone?.brand)
  }

  @Test
  fun `verify brand inference logic`() {
    assertEquals("Google", FindDeviceScraper.inferBrand("Pixel 9 Pro XL"))
    assertEquals("Samsung", FindDeviceScraper.inferBrand("Galaxy Tab S9"))
    assertEquals("Motorola", FindDeviceScraper.inferBrand("Moto Tag UWB"))
    assertEquals("Pebblebee", FindDeviceScraper.inferBrand("Pebblebee Clip"))
  }
}
